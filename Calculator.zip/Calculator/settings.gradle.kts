
rootProject.name = "Calculator"

